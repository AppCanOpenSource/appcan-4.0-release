//
//  ALBBQuPaiPlugin.h
//  ALBBQuPaiPlugin
//
//  Created by zhangwx on 16/1/17.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import "QupaiSDK.h"
#import "QPUploadTask.h"
#import "QPUploadTaskManager.h"
