//
//  SimulatorDetect.h
//  SecurityGuardSDKPro
//
//  Created by yangzhao.zy on 15/8/21.
//  Copyright (c) 2015年 alibaba. All rights reserved.
//

#ifndef SecurityGuardSDKPro_SimulatorDetect_h
#define SecurityGuardSDKPro_SimulatorDetect_h

@interface SimulatorDetect : NSObject

+ (BOOL) isSimulator;

@end

#endif
