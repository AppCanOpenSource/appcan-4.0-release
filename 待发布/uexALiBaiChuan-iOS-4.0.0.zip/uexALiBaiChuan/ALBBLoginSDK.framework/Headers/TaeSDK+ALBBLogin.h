//
//  TaeSDK+ALBBTrade.h
//  ALBBLoginSDK
//
//  Created by zhoulai on 15/3/6.
//  Copyright (c) 2015年 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ALBBSDK/ALBBSDK.h>
#import "ALBBLoginService.h"

@interface ALBBSDK (ALBBLogin) <ALBBLoginService>

@end
