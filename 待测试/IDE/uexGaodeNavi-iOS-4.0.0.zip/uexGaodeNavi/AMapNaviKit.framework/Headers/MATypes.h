//
//  MATypes.h
//  MAMapKitDemo
//
//  Created by songjian on 12-12-24.
//  Copyright (c) 2012年 songjian. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, MAMapType) {
    MAMapTypeStandard = 0,
    MAMapTypeSatellite,
    MAMapTypeStandardNight
};
//typedef NSUInteger MAMapType;
