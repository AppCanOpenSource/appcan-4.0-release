//
//  ALBBLoginSDK.h
//  ALBBLoginSDK
//
//  Created by liqing on 16/3/14.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ALBBLoginSDK.
FOUNDATION_EXPORT double ALBBLoginSDKVersionNumber;

//! Project version string for ALBBLoginSDK.
FOUNDATION_EXPORT const unsigned char ALBBLoginSDKVersionString[];

#import <ALBBLoginSDK/ALBBLoginService.h>
#import <ALBBLoginSDK/TaeSDK+ALBBLogin.h>
